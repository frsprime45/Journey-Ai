"""Skema Pydantic (validasi request & bentuk response) untuk semua endpoint."""
from datetime import datetime
from typing import Optional, List, Any
from pydantic import BaseModel, EmailStr, Field


# ---------- Auth ----------
class RegisterIn(BaseModel):
    name: str
    email: EmailStr
    password: str = Field(min_length=6)


class LoginIn(BaseModel):
    email: EmailStr
    password: str


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"


class UserOut(BaseModel):
    id: str
    name: str
    email: EmailStr
    is_admin: bool
    custom_instructions_about: str
    custom_instructions_response: str
    memory_enabled: bool
    created_at: datetime

    class Config:
        from_attributes = True


class InstructionsIn(BaseModel):
    about: str = ""
    response_style: str = ""
    memory_enabled: bool = True


# ---------- API Keys / Settings ----------
class ApiKeyIn(BaseModel):
    provider: str  # 'openai' | 'anthropic' | 'tavily'
    key: str


class ApiKeyStatusOut(BaseModel):
    provider: str
    configured: bool


# ---------- Projects ----------
class ProjectIn(BaseModel):
    name: str
    description: Optional[str] = ""
    instructions: Optional[str] = ""


class ProjectOut(BaseModel):
    id: str
    name: str
    description: str
    instructions: str
    created_at: datetime

    class Config:
        from_attributes = True


# ---------- Chats ----------
class ChatCreateIn(BaseModel):
    project_id: Optional[str] = None
    model: str = "openai:gpt-4o-mini"
    fallback_model: Optional[str] = None
    agent_mode: bool = False


class AttachmentIn(BaseModel):
    name: str
    is_image: bool = False
    text: Optional[str] = None
    data_url: Optional[str] = None


class MessageIn(BaseModel):
    content: str
    attachments: List[AttachmentIn] = []
    use_web_search: bool = False
    use_knowledge_base: bool = False


class MessageOut(BaseModel):
    id: str
    role: str
    content: str
    attachments: Any = []
    tool_trace: Any = []
    created_at: datetime

    class Config:
        from_attributes = True


class ChatOut(BaseModel):
    id: str
    title: str
    model: str
    fallback_model: Optional[str]
    agent_mode: bool
    project_id: Optional[str]
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


# ---------- Memory ----------
class MemoryIn(BaseModel):
    text: str


class MemoryOut(BaseModel):
    id: str
    text: str
    created_at: datetime

    class Config:
        from_attributes = True


# ---------- Tools ----------
class CalcIn(BaseModel):
    expression: str


class WebSearchIn(BaseModel):
    query: str
    max_results: int = 5


# ---------- RAG ----------
class RagQueryIn(BaseModel):
    query: str
    project_id: Optional[str] = None
    top_k: int = 4


# ---------- Agent ----------
class AgentRunIn(BaseModel):
    goal: str
    chat_id: Optional[str] = None
    project_id: Optional[str] = None
    max_steps: int = 5
