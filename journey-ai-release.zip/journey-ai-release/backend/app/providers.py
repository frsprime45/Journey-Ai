"""
Wrapper pemanggilan provider AI (OpenAI & Anthropic).
- Streaming (SSE) untuk Chat.
- Non-streaming untuk Agent Mode / tool-calling / embeddings.
- Fallback System: get_completion_with_fallback mencoba model utama lalu model cadangan
  kalau model utama gagal (timeout, rate limit, error API).
"""
import json
import httpx
from typing import AsyncGenerator, List, Dict, Optional

OPENAI_BASE = "https://api.openai.com/v1"
ANTHROPIC_BASE = "https://api.anthropic.com/v1"


class ProviderError(Exception):
    pass


def split_model(model_id: str):
    """'openai:gpt-4o-mini' -> ('openai', 'gpt-4o-mini')"""
    provider, _, name = model_id.partition(":")
    return provider, name


# ---------------- Streaming ----------------
async def stream_openai(model_name: str, messages: List[dict], api_key: str) -> AsyncGenerator[str, None]:
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    payload = {"model": model_name, "messages": messages, "stream": True, "temperature": 0.7}
    async with httpx.AsyncClient(timeout=60) as client:
        async with client.stream("POST", f"{OPENAI_BASE}/chat/completions", headers=headers, json=payload) as res:
            if res.status_code != 200:
                body = await res.aread()
                raise ProviderError(f"OpenAI error {res.status_code}: {body.decode(errors='ignore')[:300]}")
            async for line in res.aiter_lines():
                if not line or not line.startswith("data:"):
                    continue
                data = line[len("data:"):].strip()
                if data == "[DONE]":
                    break
                try:
                    obj = json.loads(data)
                    delta = obj["choices"][0]["delta"].get("content")
                    if delta:
                        yield delta
                except (json.JSONDecodeError, KeyError, IndexError):
                    continue


async def stream_anthropic(model_name: str, system: str, messages: List[dict], api_key: str) -> AsyncGenerator[str, None]:
    headers = {
        "x-api-key": api_key,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    }
    payload = {"model": model_name, "system": system, "messages": messages, "max_tokens": 2048, "stream": True}
    async with httpx.AsyncClient(timeout=60) as client:
        async with client.stream("POST", f"{ANTHROPIC_BASE}/messages", headers=headers, json=payload) as res:
            if res.status_code != 200:
                body = await res.aread()
                raise ProviderError(f"Anthropic error {res.status_code}: {body.decode(errors='ignore')[:300]}")
            async for line in res.aiter_lines():
                if not line or not line.startswith("data:"):
                    continue
                data = line[len("data:"):].strip()
                try:
                    obj = json.loads(data)
                    if obj.get("type") == "content_block_delta":
                        text = obj.get("delta", {}).get("text")
                        if text:
                            yield text
                except json.JSONDecodeError:
                    continue


async def stream_chat_with_fallback(
    primary_model: str,
    fallback_model: Optional[str],
    system: str,
    openai_messages: List[dict],
    anthropic_messages: List[dict],
    get_key_fn,
) -> AsyncGenerator[Dict, None]:
    """
    Coba primary_model dulu. Kalau gagal (exception apa pun sebelum ada satu token pun
    berhasil dikirim), coba fallback_model. get_key_fn(provider) -> api_key atau None.
    Yield dict event: {"type": "delta", "text": ...} atau {"type": "provider_switch", "to": ...}
    atau {"type": "error", "message": ...}
    """
    models_to_try = [primary_model] + ([fallback_model] if fallback_model else [])
    last_error = None

    for i, model_id in enumerate(models_to_try):
        if not model_id:
            continue
        provider, name = split_model(model_id)
        api_key = get_key_fn(provider)
        if not api_key:
            last_error = f"API key untuk provider '{provider}' belum diset"
            continue
        try:
            got_any_token = False
            if provider == "openai":
                gen = stream_openai(name, openai_messages, api_key)
            elif provider == "anthropic":
                gen = stream_anthropic(name, system, anthropic_messages, api_key)
            else:
                last_error = f"Provider tidak dikenali: {provider}"
                continue

            if i > 0:
                yield {"type": "provider_switch", "to": model_id}

            async for chunk in gen:
                got_any_token = True
                yield {"type": "delta", "text": chunk}

            return  # sukses, tidak perlu coba model lain
        except Exception as e:
            last_error = str(e)
            if got_any_token:
                # sudah mulai kirim jawaban parsial, jangan diam-diam ganti provider di tengah jalan
                yield {"type": "error", "message": f"Koneksi terputus di tengah jawaban: {last_error}"}
                return
            continue  # model ini gagal total sebelum kirim token, coba fallback berikutnya

    yield {"type": "error", "message": last_error or "Semua model gagal dan tidak ada fallback yang tersedia."}


# ---------------- Non-streaming (untuk Agent Mode / tool use) ----------------
async def complete_openai(model_name: str, messages: List[dict], api_key: str, tools: Optional[list] = None) -> dict:
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    payload = {"model": model_name, "messages": messages, "temperature": 0.4}
    if tools:
        payload["tools"] = tools
        payload["tool_choice"] = "auto"
    async with httpx.AsyncClient(timeout=60) as client:
        res = await client.post(f"{OPENAI_BASE}/chat/completions", headers=headers, json=payload)
        if res.status_code != 200:
            raise ProviderError(f"OpenAI error {res.status_code}: {res.text[:300]}")
        return res.json()


async def embed_openai(text: str, api_key: str, model: str = "text-embedding-3-small") -> List[float]:
    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    payload = {"model": model, "input": text}
    async with httpx.AsyncClient(timeout=30) as client:
        res = await client.post(f"{OPENAI_BASE}/embeddings", headers=headers, json=payload)
        if res.status_code != 200:
            raise ProviderError(f"OpenAI embeddings error {res.status_code}: {res.text[:300]}")
        return res.json()["data"][0]["embedding"]
