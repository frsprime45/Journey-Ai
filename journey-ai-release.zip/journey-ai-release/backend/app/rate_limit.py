"""
Rate Limit System sederhana (in-memory sliding window).
Cocok untuk single-instance server. Kalau backend nanti dijalankan di banyak instance
sekaligus (multi-process/multi-server), ganti penyimpanan counter ini ke Redis.
"""
import time
from collections import defaultdict, deque
from fastapi import HTTPException, status

_WINDOW_SECONDS = 60
_buckets: dict[str, deque] = defaultdict(deque)


def check_rate_limit(key: str, max_requests: int = 20, window_seconds: int = _WINDOW_SECONDS):
    now = time.time()
    bucket = _buckets[key]
    while bucket and bucket[0] < now - window_seconds:
        bucket.popleft()
    if len(bucket) >= max_requests:
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail=f"Terlalu banyak permintaan. Maksimum {max_requests} request per {window_seconds} detik.",
        )
    bucket.append(now)
