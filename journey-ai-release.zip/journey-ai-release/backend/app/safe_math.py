"""
Evaluator ekspresi matematika yang aman.
Tidak menggunakan eval()/exec() mentah — parsing dilakukan lewat modul `ast` dan hanya
mengizinkan operasi angka + fungsi matematika dasar, supaya tidak bisa dipakai untuk
menjalankan kode arbitrer.
"""
import ast
import math
import operator

_ALLOWED_BINOPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Pow: operator.pow,
    ast.Mod: operator.mod,
    ast.FloorDiv: operator.floordiv,
}
_ALLOWED_UNARYOPS = {
    ast.UAdd: operator.pos,
    ast.USub: operator.neg,
}
_ALLOWED_FUNCS = {
    "sqrt": math.sqrt, "sin": math.sin, "cos": math.cos, "tan": math.tan,
    "log": math.log, "log10": math.log10, "exp": math.exp, "abs": abs,
    "round": round, "floor": math.floor, "ceil": math.ceil,
    "pi": math.pi, "e": math.e,
}


class MathEvalError(Exception):
    pass


def _eval_node(node):
    if isinstance(node, ast.Expression):
        return _eval_node(node.body)
    if isinstance(node, ast.Num):  # py<3.8 compat
        return node.n
    if isinstance(node, ast.Constant):
        if isinstance(node.value, (int, float)):
            return node.value
        raise MathEvalError("Hanya angka yang diperbolehkan")
    if isinstance(node, ast.BinOp) and type(node.op) in _ALLOWED_BINOPS:
        return _ALLOWED_BINOPS[type(node.op)](_eval_node(node.left), _eval_node(node.right))
    if isinstance(node, ast.UnaryOp) and type(node.op) in _ALLOWED_UNARYOPS:
        return _ALLOWED_UNARYOPS[type(node.op)](_eval_node(node.operand))
    if isinstance(node, ast.Call):
        if isinstance(node.func, ast.Name) and node.func.id in _ALLOWED_FUNCS:
            fn = _ALLOWED_FUNCS[node.func.id]
            args = [_eval_node(a) for a in node.args]
            return fn(*args) if callable(fn) else fn
        raise MathEvalError("Fungsi tidak dikenali")
    if isinstance(node, ast.Name) and node.id in _ALLOWED_FUNCS:
        val = _ALLOWED_FUNCS[node.id]
        if callable(val):
            raise MathEvalError("Nama fungsi harus dipanggil dengan ()")
        return val
    raise MathEvalError(f"Ekspresi tidak diizinkan: {ast.dump(node)}")


def safe_eval(expression: str) -> float:
    expression = expression.replace("^", "**")
    try:
        tree = ast.parse(expression, mode="eval")
    except SyntaxError:
        raise MathEvalError("Sintaks ekspresi tidak valid")
    return _eval_node(tree)
