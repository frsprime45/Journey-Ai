"""Ekstraksi teks dari file upload (PDF/DOCX/TXT/CSV/JSON) di sisi server."""
import io
from fastapi import UploadFile


async def extract_text_from_upload(file: UploadFile) -> str:
    name = (file.filename or "").lower()
    raw = await file.read()

    try:
        if name.endswith((".txt", ".md", ".csv", ".json")):
            return raw.decode(errors="ignore")

        if name.endswith(".pdf"):
            from pypdf import PdfReader
            reader = PdfReader(io.BytesIO(raw))
            text = ""
            for page in reader.pages[:30]:
                text += (page.extract_text() or "") + "\n"
            return text

        if name.endswith(".docx"):
            import docx
            doc = docx.Document(io.BytesIO(raw))
            return "\n".join(p.text for p in doc.paragraphs)

    except Exception as e:
        return f"[Gagal mengekstrak isi file: {e}]"

    return "[Format file belum didukung untuk ekstraksi otomatis di server]"
