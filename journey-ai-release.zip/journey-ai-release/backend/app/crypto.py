"""
Enkripsi simetris (Fernet) untuk API key pihak ketiga yang disimpan di database.
Key enkripsi (SECRET_ENCRYPTION_KEY) HARUS diisi di .env dan dijaga kerahasiaannya —
siapa pun yang punya key ini + akses database bisa membaca API key pengguna.

Cara generate key baru:
    python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
"""
import os
from cryptography.fernet import Fernet, InvalidToken

_key = os.getenv("SECRET_ENCRYPTION_KEY")
if not _key:
    raise RuntimeError(
        "SECRET_ENCRYPTION_KEY belum diset di .env. "
        "Generate dengan: python -c \"from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())\""
    )
_fernet = Fernet(_key.encode())


def encrypt_key(plaintext: str) -> str:
    return _fernet.encrypt(plaintext.encode()).decode()


def decrypt_key(token: str) -> str:
    try:
        return _fernet.decrypt(token.encode()).decode()
    except InvalidToken:
        raise ValueError("Gagal mendekripsi API key — SECRET_ENCRYPTION_KEY mungkin berubah.")
