from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.database import get_db
from app import models, auth

router = APIRouter(prefix="/admin", tags=["admin"])


@router.get("/users")
def list_users(admin: models.User = Depends(auth.require_admin), db: Session = Depends(get_db)):
    users = db.query(models.User).all()
    out = []
    for u in users:
        chat_count = db.query(func.count(models.Chat.id)).filter(models.Chat.user_id == u.id).scalar()
        out.append({
            "id": u.id, "name": u.name, "email": u.email, "is_admin": u.is_admin,
            "is_active": u.is_active, "created_at": u.created_at, "chat_count": chat_count,
        })
    return out


@router.post("/users/{user_id}/disable")
def disable_user(user_id: str, admin: models.User = Depends(auth.require_admin), db: Session = Depends(get_db)):
    user = db.query(models.User).filter_by(id=user_id).first()
    if not user:
        raise HTTPException(404, "Pengguna tidak ditemukan")
    if user.id == admin.id:
        raise HTTPException(400, "Tidak bisa menonaktifkan akun sendiri")
    user.is_active = False
    db.commit()
    return {"ok": True}


@router.post("/users/{user_id}/enable")
def enable_user(user_id: str, admin: models.User = Depends(auth.require_admin), db: Session = Depends(get_db)):
    user = db.query(models.User).filter_by(id=user_id).first()
    if not user:
        raise HTTPException(404, "Pengguna tidak ditemukan")
    user.is_active = True
    db.commit()
    return {"ok": True}


@router.get("/usage")
def usage_stats(admin: models.User = Depends(auth.require_admin), db: Session = Depends(get_db)):
    total_requests = db.query(func.count(models.UsageLog.id)).scalar()
    total_prompt_tokens = db.query(func.sum(models.UsageLog.prompt_tokens_est)).scalar() or 0
    total_completion_tokens = db.query(func.sum(models.UsageLog.completion_tokens_est)).scalar() or 0
    failed_requests = db.query(func.count(models.UsageLog.id)).filter(models.UsageLog.success == False).scalar()  # noqa: E712

    by_model = (
        db.query(models.UsageLog.model, func.count(models.UsageLog.id))
        .group_by(models.UsageLog.model)
        .all()
    )
    return {
        "total_requests": total_requests,
        "failed_requests": failed_requests,
        "total_prompt_tokens_est": total_prompt_tokens,
        "total_completion_tokens_est": total_completion_tokens,
        "requests_by_model": [{"model": m, "count": c} for m, c in by_model],
        "total_users": db.query(func.count(models.User.id)).scalar(),
    }
