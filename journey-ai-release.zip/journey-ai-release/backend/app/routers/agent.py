"""
Agent Mode / Tool Calling.
Loop sederhana: model diberi daftar tool (web_search, calculator, knowledge_base_query).
Kalau model minta panggil tool, kita jalankan tool itu di server lalu kirim hasilnya
balik ke model, sampai model memberi jawaban akhir atau batas langkah tercapai.
Ini juga menjadi dasar kasar untuk "Deep Research" (riset dari beberapa sumber lalu
disusun jadi satu jawaban) dengan menaikkan max_steps & menyuruh model memanggil
web_search beberapa kali dengan query berbeda.
"""
import json
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app import models, schemas, auth
from app.providers import complete_openai, ProviderError, split_model
from app.routers.settings import get_user_key
from app.routers.tools import run_web_search
from app.safe_math import safe_eval, MathEvalError
from app.rate_limit import check_rate_limit

router = APIRouter(prefix="/agent", tags=["agent"])

TOOL_DEFS = [
    {
        "type": "function",
        "function": {
            "name": "web_search",
            "description": "Cari informasi terbaru di internet.",
            "parameters": {
                "type": "object",
                "properties": {"query": {"type": "string"}},
                "required": ["query"],
            },
        },
    },
    {
        "type": "function",
        "function": {
            "name": "calculator",
            "description": "Hitung ekspresi matematika secara akurat.",
            "parameters": {
                "type": "object",
                "properties": {"expression": {"type": "string"}},
                "required": ["expression"],
            },
        },
    },
]


@router.post("/run")
async def run_agent(data: schemas.AgentRunIn, user: models.User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    check_rate_limit(f"agent:{user.id}", max_requests=5, window_seconds=60)

    openai_key = get_user_key(db, user.id, "openai")
    if not openai_key:
        raise HTTPException(400, "Agent Mode saat ini butuh API key OpenAI (memakai tool/function calling).")
    tavily_key = get_user_key(db, user.id, "tavily")

    messages = [
        {"role": "system", "content": (
            "Kamu adalah agent yang menyelesaikan tugas selangkah demi selangkah. "
            "Gunakan tool bila perlu data terbaru atau hitungan pasti. "
            "Kalau sudah cukup informasi, beri jawaban akhir yang jelas dan ringkas dalam Bahasa Indonesia."
        )},
        {"role": "user", "content": data.goal},
    ]
    trace = []

    for step in range(data.max_steps):
        try:
            result = await complete_openai("gpt-4o-mini", messages, openai_key, tools=TOOL_DEFS)
        except ProviderError as e:
            raise HTTPException(502, str(e))

        choice = result["choices"][0]["message"]
        tool_calls = choice.get("tool_calls")

        if not tool_calls:
            final_answer = choice.get("content", "")
            return {"answer": final_answer, "steps": trace}

        messages.append(choice)
        for call in tool_calls:
            fn_name = call["function"]["name"]
            try:
                args = json.loads(call["function"]["arguments"])
            except json.JSONDecodeError:
                args = {}

            tool_output = ""
            if fn_name == "web_search":
                if not tavily_key:
                    tool_output = "Tool web_search tidak tersedia: API key Tavily belum diset."
                else:
                    try:
                        results = await run_web_search(args.get("query", ""), tavily_key, 5)
                        tool_output = json.dumps(results, ensure_ascii=False)
                    except HTTPException as e:
                        tool_output = f"Web search gagal: {e.detail}"
            elif fn_name == "calculator":
                try:
                    tool_output = str(safe_eval(args.get("expression", "")))
                except MathEvalError as e:
                    tool_output = f"Error: {e}"
            else:
                tool_output = "Tool tidak dikenali"

            trace.append({"step": step + 1, "tool": fn_name, "args": args, "output": tool_output[:800]})
            messages.append({"role": "tool", "tool_call_id": call["id"], "content": tool_output})

    return {"answer": "Batas langkah agent tercapai sebelum mendapat jawaban akhir.", "steps": trace}
