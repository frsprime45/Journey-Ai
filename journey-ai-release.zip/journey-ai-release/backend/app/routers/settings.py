from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app import models, schemas, auth, crypto

router = APIRouter(prefix="/settings", tags=["settings"])

ALLOWED_PROVIDERS = {"openai", "anthropic", "tavily"}


@router.put("/api-keys")
def set_api_key(data: schemas.ApiKeyIn, user: models.User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    if data.provider not in ALLOWED_PROVIDERS:
        return {"error": f"Provider tidak dikenali. Pilihan: {ALLOWED_PROVIDERS}"}
    existing = db.query(models.ApiKey).filter_by(user_id=user.id, provider=data.provider).first()
    encrypted = crypto.encrypt_key(data.key)
    if existing:
        existing.encrypted_key = encrypted
    else:
        db.add(models.ApiKey(user_id=user.id, provider=data.provider, encrypted_key=encrypted))
    db.commit()
    return {"ok": True, "provider": data.provider}


@router.get("/api-keys", response_model=list[schemas.ApiKeyStatusOut])
def list_api_keys(user: models.User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    configured = {k.provider for k in db.query(models.ApiKey).filter_by(user_id=user.id).all()}
    return [{"provider": p, "configured": p in configured} for p in ALLOWED_PROVIDERS]


@router.delete("/api-keys/{provider}")
def delete_api_key(provider: str, user: models.User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    db.query(models.ApiKey).filter_by(user_id=user.id, provider=provider).delete()
    db.commit()
    return {"ok": True}


@router.put("/instructions", response_model=schemas.UserOut)
def update_instructions(data: schemas.InstructionsIn, user: models.User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    user.custom_instructions_about = data.about
    user.custom_instructions_response = data.response_style
    user.memory_enabled = data.memory_enabled
    db.commit()
    db.refresh(user)
    return user


def get_user_key(db: Session, user_id: str, provider: str) -> str | None:
    row = db.query(models.ApiKey).filter_by(user_id=user_id, provider=provider).first()
    if not row:
        return None
    return crypto.decrypt_key(row.encrypted_key)
