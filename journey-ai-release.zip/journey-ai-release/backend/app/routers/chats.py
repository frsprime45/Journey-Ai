import json
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app.database import get_db
from app import models, schemas, auth
from app.providers import stream_chat_with_fallback, split_model
from app.routers.settings import get_user_key
from app.rate_limit import check_rate_limit

router = APIRouter(prefix="/chats", tags=["chats"])


@router.post("", response_model=schemas.ChatOut)
def create_chat(data: schemas.ChatCreateIn, user: models.User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    chat = models.Chat(
        user_id=user.id, project_id=data.project_id, model=data.model,
        fallback_model=data.fallback_model, agent_mode=data.agent_mode,
    )
    db.add(chat)
    db.commit()
    db.refresh(chat)
    return chat


@router.get("", response_model=list[schemas.ChatOut])
def list_chats(user: models.User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    return db.query(models.Chat).filter_by(user_id=user.id).order_by(models.Chat.updated_at.desc()).all()


@router.get("/{chat_id}")
def get_chat(chat_id: str, user: models.User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    chat = db.query(models.Chat).filter_by(id=chat_id, user_id=user.id).first()
    if not chat:
        raise HTTPException(404, "Chat tidak ditemukan")
    return {
        "id": chat.id, "title": chat.title, "model": chat.model,
        "fallback_model": chat.fallback_model, "agent_mode": chat.agent_mode,
        "project_id": chat.project_id,
        "messages": [
            {"id": m.id, "role": m.role, "content": m.content, "attachments": m.attachments,
             "tool_trace": m.tool_trace, "created_at": m.created_at}
            for m in chat.messages
        ],
    }


@router.delete("/{chat_id}")
def delete_chat(chat_id: str, user: models.User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    chat = db.query(models.Chat).filter_by(id=chat_id, user_id=user.id).first()
    if not chat:
        raise HTTPException(404, "Chat tidak ditemukan")
    db.delete(chat)
    db.commit()
    return {"ok": True}


def build_system_prompt(user: models.User, chat: models.Chat, kb_context: str = "") -> str:
    parts = ["Kamu adalah Journey AI, asisten AI yang membantu, jujur, dan ringkas."]
    if user.custom_instructions_about:
        parts.append(f"Tentang pengguna: {user.custom_instructions_about}")
    if user.custom_instructions_response:
        parts.append(f"Gaya respons yang diinginkan: {user.custom_instructions_response}")
    if user.memory_enabled and user.memory_facts:
        facts = "\n".join(f"- {f.text}" for f in user.memory_facts)
        parts.append(f"Informasi yang diizinkan untuk diingat tentang pengguna:\n{facts}")
    if chat.project:
        if chat.project.instructions:
            parts.append(f"Instruksi khusus project '{chat.project.name}': {chat.project.instructions}")
        if chat.project.files:
            files_ctx = "\n\n".join(f"[{f.name}]\n{f.text_content[:3000]}" for f in chat.project.files)
            parts.append(f"Konteks file project:\n{files_ctx}")
    if kb_context:
        parts.append(f"Potongan dokumen relevan dari Knowledge Base:\n{kb_context}")
    return "\n\n".join(parts)


def build_provider_messages(chat_messages: list[models.Message]):
    """Bentuk pesan untuk OpenAI (vision-capable) dan Anthropic sekaligus."""
    openai_msgs, anthropic_msgs = [], []
    for m in chat_messages:
        atts = m.attachments or []
        has_image = any(a.get("is_image") for a in atts)

        # OpenAI format
        if has_image:
            content = []
            if m.content:
                content.append({"type": "text", "text": m.content})
            for a in atts:
                if a.get("is_image") and a.get("data_url"):
                    content.append({"type": "image_url", "image_url": {"url": a["data_url"]}})
                elif a.get("text"):
                    content.append({"type": "text", "text": f"[File: {a['name']}]\n{a['text'][:4000]}"})
            openai_msgs.append({"role": m.role, "content": content})
        else:
            text = m.content or ""
            file_atts = [a for a in atts if a.get("text")]
            if file_atts:
                text += "\n\n" + "\n\n".join(f"[File: {a['name']}]\n{a['text'][:4000]}" for a in file_atts)
            openai_msgs.append({"role": m.role, "content": text})

        # Anthropic format
        a_content = []
        if m.content:
            a_content.append({"type": "text", "text": m.content})
        for a in atts:
            if a.get("is_image") and a.get("data_url"):
                try:
                    meta, b64 = a["data_url"].split(";base64,")
                    media_type = meta.split(":")[1]
                    a_content.append({"type": "image", "source": {"type": "base64", "media_type": media_type, "data": b64}})
                except ValueError:
                    pass
            elif a.get("text"):
                a_content.append({"type": "text", "text": f"[File: {a['name']}]\n{a['text'][:4000]}"})
        anthropic_msgs.append({"role": "assistant" if m.role == "assistant" else "user", "content": a_content})

    return openai_msgs, anthropic_msgs


@router.post("/{chat_id}/messages")
async def send_message(
    chat_id: str,
    data: schemas.MessageIn,
    user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    check_rate_limit(f"chat:{user.id}", max_requests=30, window_seconds=60)

    chat = db.query(models.Chat).filter_by(id=chat_id, user_id=user.id).first()
    if not chat:
        raise HTTPException(404, "Chat tidak ditemukan")

    provider, _ = split_model(chat.model)
    if not get_user_key(db, user.id, provider):
        raise HTTPException(400, f"API key untuk provider '{provider}' belum diset di Settings.")

    user_msg = models.Message(
        chat_id=chat.id, role="user", content=data.content,
        attachments=[a.model_dump() for a in data.attachments],
    )
    db.add(user_msg)
    if chat.title == "Percakapan Baru" and data.content:
        chat.title = data.content[:42]
    chat.updated_at = datetime.utcnow()
    db.commit()

    # --- Konteks tambahan opsional: web search & knowledge base ---
    kb_context = ""
    tool_trace = []
    if data.use_knowledge_base:
        from app.routers.rag import query_knowledge_base
        from app.schemas import RagQueryIn
        try:
            kb_res = await query_knowledge_base(RagQueryIn(query=data.content, project_id=chat.project_id, top_k=4), user, db)
            kb_context = "\n\n".join(r["text"] for r in kb_res["results"])
            tool_trace.append({"tool": "knowledge_base", "found": len(kb_res["results"])})
        except HTTPException as e:
            tool_trace.append({"tool": "knowledge_base", "error": e.detail})

    if data.use_web_search:
        from app.routers.tools import run_web_search
        api_key = get_user_key(db, user.id, "tavily")
        if api_key:
            try:
                results = await run_web_search(data.content, api_key, 5)
                web_ctx = "\n".join(f"- {r['title']}: {r['snippet']} ({r['url']})" for r in results)
                kb_context = (kb_context + "\n\n" if kb_context else "") + f"Hasil web search:\n{web_ctx}"
                tool_trace.append({"tool": "web_search", "results": results})
            except HTTPException as e:
                tool_trace.append({"tool": "web_search", "error": e.detail})
        else:
            tool_trace.append({"tool": "web_search", "error": "API key Tavily belum diset"})

    system = build_system_prompt(user, chat, kb_context)
    openai_msgs, anthropic_msgs = build_provider_messages(chat.messages)

    def get_key(provider_name: str):
        return get_user_key(db, user.id, provider_name)

    async def event_stream():
        full_text = ""
        async for event in stream_chat_with_fallback(
            chat.model, chat.fallback_model, system, openai_msgs, anthropic_msgs, get_key
        ):
            if event["type"] == "delta":
                full_text += event["text"]
            yield f"data: {json.dumps(event)}\n\n"

        assistant_msg = models.Message(chat_id=chat.id, role="assistant", content=full_text, tool_trace=tool_trace)
        db.add(assistant_msg)
        db.add(models.UsageLog(
            user_id=user.id, endpoint="chats.messages", provider=provider, model=chat.model,
            prompt_tokens_est=len(data.content) // 4, completion_tokens_est=len(full_text) // 4,
            success=bool(full_text),
        ))
        chat.updated_at = datetime.utcnow()
        db.commit()
        yield "data: [DONE]\n\n"

    return StreamingResponse(event_stream(), media_type="text/event-stream")
