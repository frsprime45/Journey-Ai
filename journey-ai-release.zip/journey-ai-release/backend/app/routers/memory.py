from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app import models, schemas, auth

router = APIRouter(prefix="/memory", tags=["memory"])


@router.get("", response_model=list[schemas.MemoryOut])
def list_memory(user: models.User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    return db.query(models.MemoryFact).filter_by(user_id=user.id).order_by(models.MemoryFact.created_at.desc()).all()


@router.post("", response_model=schemas.MemoryOut)
def add_memory(data: schemas.MemoryIn, user: models.User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    fact = models.MemoryFact(user_id=user.id, text=data.text)
    db.add(fact)
    db.commit()
    db.refresh(fact)
    return fact


@router.delete("/{fact_id}")
def delete_memory(fact_id: str, user: models.User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    fact = db.query(models.MemoryFact).filter_by(id=fact_id, user_id=user.id).first()
    if not fact:
        raise HTTPException(404, "Fakta memory tidak ditemukan")
    db.delete(fact)
    db.commit()
    return {"ok": True}
