"""
RAG / Knowledge Base ringan:
- Upload dokumen -> dipecah jadi potongan (~350 kata) -> di-embed via OpenAI embeddings
  -> disimpan sebagai JSON vector di tabel knowledge_chunks.
- Query -> embed query -> cosine similarity terhadap semua chunk milik user (atau project
  tertentu) -> kembalikan top-k potongan paling relevan.
Untuk skala besar (>~5000 chunk), pindahkan similarity search ke database vektor
sungguhan (pgvector, Qdrant, dll) — pendekatan in-Python ini cukup untuk knowledge base
pribadi/tim kecil.
"""
import math
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session

from app.database import get_db
from app import models, schemas, auth
from app.utils_extract import extract_text_from_upload
from app.providers import embed_openai, ProviderError
from app.routers.settings import get_user_key

router = APIRouter(prefix="/rag", tags=["rag"])


def chunk_text(text: str, words_per_chunk: int = 350) -> list[str]:
    words = text.split()
    return [" ".join(words[i:i + words_per_chunk]) for i in range(0, len(words), words_per_chunk)] or []


def cosine_similarity(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(y * y for y in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


@router.post("/documents")
async def upload_document(
    file: UploadFile = File(...),
    project_id: str | None = None,
    user: models.User = Depends(auth.get_current_user),
    db: Session = Depends(get_db),
):
    api_key = get_user_key(db, user.id, "openai")
    if not api_key:
        raise HTTPException(400, "API key OpenAI dibutuhkan untuk membuat embedding (RAG).")

    text = await extract_text_from_upload(file)
    chunks = chunk_text(text)
    if not chunks:
        raise HTTPException(400, "Tidak ada teks yang bisa diekstrak dari file ini.")

    saved = 0
    for chunk in chunks:
        try:
            vector = await embed_openai(chunk, api_key)
        except ProviderError as e:
            raise HTTPException(502, str(e))
        db.add(models.KnowledgeChunk(
            user_id=user.id, project_id=project_id, source_name=file.filename,
            chunk_text=chunk, embedding=vector,
        ))
        saved += 1
    db.commit()
    return {"ok": True, "file": file.filename, "chunks_saved": saved}


@router.post("/query")
async def query_knowledge_base(data: schemas.RagQueryIn, user: models.User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    api_key = get_user_key(db, user.id, "openai")
    if not api_key:
        raise HTTPException(400, "API key OpenAI dibutuhkan untuk RAG.")

    q = db.query(models.KnowledgeChunk).filter_by(user_id=user.id)
    if data.project_id:
        q = q.filter_by(project_id=data.project_id)
    chunks = q.all()
    if not chunks:
        return {"query": data.query, "results": []}

    query_vector = await embed_openai(data.query, api_key)
    scored = [
        {"source": c.source_name, "text": c.chunk_text, "score": cosine_similarity(query_vector, c.embedding)}
        for c in chunks
    ]
    scored.sort(key=lambda x: x["score"], reverse=True)
    return {"query": data.query, "results": scored[:data.top_k]}


@router.get("/documents")
def list_documents(project_id: str | None = None, user: models.User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    q = db.query(models.KnowledgeChunk.source_name).filter_by(user_id=user.id)
    if project_id:
        q = q.filter_by(project_id=project_id)
    names = sorted({row[0] for row in q.all()})
    return {"documents": names}


@router.delete("/documents/{source_name}")
def delete_document(source_name: str, user: models.User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    db.query(models.KnowledgeChunk).filter_by(user_id=user.id, source_name=source_name).delete()
    db.commit()
    return {"ok": True}
