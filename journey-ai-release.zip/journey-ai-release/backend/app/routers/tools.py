import httpx
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app import models, schemas, auth
from app.safe_math import safe_eval, MathEvalError
from app.rate_limit import check_rate_limit
from app.routers.settings import get_user_key

router = APIRouter(prefix="/tools", tags=["tools"])

TAVILY_URL = "https://api.tavily.com/search"


@router.post("/calculator")
def calculator(data: schemas.CalcIn, user: models.User = Depends(auth.get_current_user)):
    try:
        result = safe_eval(data.expression)
        return {"expression": data.expression, "result": result}
    except MathEvalError as e:
        raise HTTPException(400, str(e))
    except ZeroDivisionError:
        raise HTTPException(400, "Pembagian dengan nol")


async def run_web_search(query: str, api_key: str, max_results: int = 5) -> list[dict]:
    """Dipanggil juga dari agent.py sebagai tool. Butuh API key Tavily milik user."""
    async with httpx.AsyncClient(timeout=20) as client:
        res = await client.post(TAVILY_URL, json={
            "api_key": api_key, "query": query, "max_results": max_results,
        })
        if res.status_code != 200:
            raise HTTPException(502, f"Web search gagal: {res.text[:200]}")
        data = res.json()
        return [
            {"title": r.get("title"), "url": r.get("url"), "snippet": r.get("content", "")[:400]}
            for r in data.get("results", [])
        ]


@router.post("/web-search")
async def web_search(data: schemas.WebSearchIn, user: models.User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    check_rate_limit(f"websearch:{user.id}", max_requests=15, window_seconds=60)
    api_key = get_user_key(db, user.id, "tavily")
    if not api_key:
        raise HTTPException(400, "API key Tavily belum diset di Settings > Models & API Key. Daftar gratis di tavily.com.")
    results = await run_web_search(data.query, api_key, data.max_results)
    return {"query": data.query, "results": results}
