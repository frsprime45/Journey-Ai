from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session

from app.database import get_db
from app import models, schemas, auth
from app.utils_extract import extract_text_from_upload

router = APIRouter(prefix="/projects", tags=["projects"])


@router.post("", response_model=schemas.ProjectOut)
def create_project(data: schemas.ProjectIn, user: models.User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    proj = models.Project(user_id=user.id, name=data.name, description=data.description, instructions=data.instructions)
    db.add(proj)
    db.commit()
    db.refresh(proj)
    return proj


@router.get("", response_model=list[schemas.ProjectOut])
def list_projects(user: models.User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    return db.query(models.Project).filter_by(user_id=user.id).order_by(models.Project.created_at.desc()).all()


@router.put("/{project_id}", response_model=schemas.ProjectOut)
def update_project(project_id: str, data: schemas.ProjectIn, user: models.User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    proj = db.query(models.Project).filter_by(id=project_id, user_id=user.id).first()
    if not proj:
        raise HTTPException(404, "Project tidak ditemukan")
    proj.name, proj.description, proj.instructions = data.name, data.description, data.instructions
    db.commit()
    db.refresh(proj)
    return proj


@router.delete("/{project_id}")
def delete_project(project_id: str, user: models.User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    proj = db.query(models.Project).filter_by(id=project_id, user_id=user.id).first()
    if not proj:
        raise HTTPException(404, "Project tidak ditemukan")
    db.delete(proj)
    db.commit()
    return {"ok": True}


@router.post("/{project_id}/files")
async def upload_project_file(project_id: str, file: UploadFile = File(...), user: models.User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    proj = db.query(models.Project).filter_by(id=project_id, user_id=user.id).first()
    if not proj:
        raise HTTPException(404, "Project tidak ditemukan")
    text = await extract_text_from_upload(file)
    pf = models.ProjectFile(project_id=project_id, name=file.filename, text_content=text)
    db.add(pf)
    db.commit()
    return {"ok": True, "name": file.filename, "chars_extracted": len(text)}


@router.get("/{project_id}/files")
def list_project_files(project_id: str, user: models.User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    proj = db.query(models.Project).filter_by(id=project_id, user_id=user.id).first()
    if not proj:
        raise HTTPException(404, "Project tidak ditemukan")
    return [{"id": f.id, "name": f.name, "created_at": f.created_at} for f in proj.files]


@router.delete("/{project_id}/files/{file_id}")
def delete_project_file(project_id: str, file_id: str, user: models.User = Depends(auth.get_current_user), db: Session = Depends(get_db)):
    pf = db.query(models.ProjectFile).join(models.Project).filter(
        models.ProjectFile.id == file_id, models.Project.id == project_id, models.Project.user_id == user.id
    ).first()
    if not pf:
        raise HTTPException(404, "File tidak ditemukan")
    db.delete(pf)
    db.commit()
    return {"ok": True}
