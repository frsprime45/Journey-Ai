"""
Journey AI — Backend API
Jalankan dengan: uvicorn app.main:app --reload
Dokumentasi interaktif otomatis tersedia di /docs setelah server jalan.
"""
import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

load_dotenv()

from app.database import Base, engine
from app import models  # noqa: F401  (import supaya semua model terdaftar sebelum create_all)
from app.routers import auth, settings, projects, chats, memory, tools, rag, agent, admin

app = FastAPI(
    title="Journey AI API",
    description="Backend untuk Journey AI: chat multi-model, projects, memory, RAG, agent mode, dan admin dashboard.",
    version="1.0.0",
)

allowed_origins = os.getenv("ALLOWED_ORIGINS", "*").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(settings.router)
app.include_router(projects.router)
app.include_router(chats.router)
app.include_router(memory.router)
app.include_router(tools.router)
app.include_router(rag.router)
app.include_router(agent.router)
app.include_router(admin.router)


@app.on_event("startup")
def on_startup():
    Base.metadata.create_all(bind=engine)


@app.get("/")
def root():
    return {"name": "Journey AI API", "status": "ok", "docs": "/docs"}


@app.get("/health")
def health():
    return {"status": "ok"}
