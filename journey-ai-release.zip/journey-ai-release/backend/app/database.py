"""
Konfigurasi koneksi database.
Default: SQLite (file lokal journey_ai.db) — cukup untuk single-server / skala kecil-menengah.
Untuk produksi yang lebih besar, ganti DATABASE_URL di .env ke PostgreSQL/MySQL,
kode ini tidak berubah karena SQLAlchemy yang menangani perbedaan dialect.
"""
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./journey_ai.db")

connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
