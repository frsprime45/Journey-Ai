# Journey AI — Backend

Backend Python (FastAPI) + SQL untuk Journey AI. Ini melengkapi frontend (`index.html` +
`app.js`) yang sudah dibuat sebelumnya, dengan fitur yang tidak mungkin jalan aman di
browser saja: **penyimpanan API key di server**, **autentikasi sungguhan**, **Web Search**,
**RAG/Knowledge Base**, **Agent Mode**, **Rate Limiting**, **Fallback System**, dan
**Admin Dashboard**.

> **Wajib dijalankan dengan Python** — tidak ada cara membuat backend "hidup" tanpa
> menjalankan sesuatu (baik di komputer sendiri, maupun di layanan hosting). Panduan di
> bawah ini sudah selengkap mungkin supaya tinggal ikut langkahnya.

## 1. Instalasi

Butuh Python 3.10+ terpasang di komputer.

```bash
cd journey-ai-backend
python3 -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## 2. Konfigurasi

```bash
cp .env.example .env
```

Lalu isi 2 nilai wajib di file `.env`:

```bash
# Generate JWT secret:
python3 -c "import secrets; print(secrets.token_hex(32))"

# Generate encryption key untuk API key pengguna:
python3 -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
```

Tempel hasilnya ke `JWT_SECRET_KEY` dan `SECRET_ENCRYPTION_KEY` di `.env`.

## 3. Jalankan

```bash
uvicorn app.main:app --reload
```

Server jalan di `http://127.0.0.1:8000`. Buka `http://127.0.0.1:8000/docs` untuk
dokumentasi interaktif (Swagger UI) — dari situ kamu sudah bisa mencoba **semua**
endpoint langsung dari browser tanpa menulis kode tambahan:

1. `POST /auth/register` → buat akun (user pertama otomatis jadi admin).
2. `POST /auth/login` → dapat `access_token`.
3. Klik tombol **Authorize** di `/docs`, isi `Bearer <access_token>`.
4. `PUT /settings/api-keys` → simpan API key OpenAI/Anthropic/Tavily (dienkripsi di DB).
5. `POST /chats` → buat chat, lalu `POST /chats/{id}/messages` → mulai ngobrol
   (respons berupa stream Server-Sent Events).

## 4. Struktur proyek

```
app/
  main.py           entry point FastAPI, CORS, daftar router
  database.py       koneksi SQLAlchemy (SQLite default)
  models.py         tabel: users, api_keys, chats, messages, projects,
                     project_files, memory_facts, knowledge_chunks, usage_logs
  schemas.py        skema request/response (Pydantic)
  auth.py           hashing password, JWT, dependency get_current_user/require_admin
  crypto.py         enkripsi API key (Fernet)
  providers.py      pemanggilan OpenAI/Anthropic (streaming + fallback)
  safe_math.py      evaluator ekspresi matematika aman (untuk Calculator tool)
  rate_limit.py     rate limiting in-memory
  utils_extract.py  ekstraksi teks dari PDF/DOCX/TXT sisi server
  routers/
    auth.py         register, login, me
    settings.py      simpan/hapus API key, custom instructions
    projects.py      CRUD project + upload file project
    chats.py         CRUD chat + kirim pesan (streaming, fallback, web search, RAG)
    memory.py        AI Memory (CRUD fakta)
    tools.py         Calculator + Web Search (Tavily)
    rag.py           upload dokumen + query Knowledge Base (embedding OpenAI)
    agent.py         Agent Mode (tool-calling loop OpenAI)
    admin.py         Admin Dashboard (daftar user, usage stats, disable user)
schema.sql          versi SQL mentah dari seluruh tabel (referensi/dokumentasi)
```

## 5. Catatan tiap fitur

- **Autentikasi & Keamanan** — password di-hash dengan bcrypt, sesi berbasis JWT,
  API key pihak ketiga dienkripsi (Fernet) sebelum disimpan di database, tidak pernah
  dikirim balik ke frontend dalam bentuk plaintext.
- **Web Search** — pakai [Tavily](https://tavily.com) (ada tier gratis). Simpan API
  key Tavily lewat `PUT /settings/api-keys` dengan `provider: "tavily"`.
- **RAG / Knowledge Base** — dokumen dipecah jadi potongan ~350 kata, di-embed pakai
  OpenAI `text-embedding-3-small`, dicari pakai cosine similarity langsung di Python.
  Cocok untuk knowledge base pribadi/tim kecil; kalau dokumennya sangat banyak
  (>~5.000 potongan), pertimbangkan pindah ke database vektor seperti pgvector/Qdrant.
- **Agent Mode / Tool Calling** — loop maksimal `max_steps` (default 5): model boleh
  memanggil `web_search` atau `calculator`, hasilnya dikembalikan ke model, sampai
  model memberi jawaban akhir. Bisa jadi dasar "Deep Research" dengan menaikkan
  `max_steps` dan membiarkan model memanggil `web_search` berkali-kali.
- **Fallback System** — tiap chat punya `model` (utama) dan `fallback_model`
  (opsional). Kalau model utama gagal total sebelum mengirim satu token pun,
  otomatis coba `fallback_model`.
- **Rate Limit System** — in-memory sliding window per user per jenis endpoint.
  Untuk deployment multi-instance, ganti penyimpanan counter-nya ke Redis.
- **Code execution sungguhan** (menjalankan kode yang ditulis pengguna) **sengaja
  tidak disediakan** di backend ini karena butuh sandbox terisolasi (container/VM
  terpisah) supaya aman — di luar cakupan proyek awal ini.

## 6. Menghubungkan ke frontend (index.html + app.js)

Backend ini berjalan independen dan sudah bisa dicoba penuh lewat `/docs`. Untuk
menyambungkannya ke frontend yang sudah dibuat sebelumnya, langkah besarnya:

1. Ganti layar login lokal di `app.js` dengan pemanggilan `POST /auth/register` /
   `POST /auth/login`, simpan `access_token` yang didapat.
2. Ganti fungsi `streamOpenAI` / `streamAnthropic` di `app.js` supaya memanggil
   `POST {BACKEND_URL}/chats/{id}/messages` (dengan header `Authorization: Bearer
   <token>`) alih-alih memanggil OpenAI/Anthropic langsung dari browser.
3. Ganti penyimpanan API key di Settings supaya memanggil `PUT /settings/api-keys`
   alih-alih disimpan di `localStorage`.

Kalau kamu mau, saya bisa langsung kerjakan penyambungan frontend↔backend ini di
langkah berikutnya — tinggal bilang saja.
