# Journey AI — Paket Lengkap

Paket ini berisi 2 bagian:

```
frontend/   → index.html + app.js
             Buka index.html langsung di browser, tanpa terminal.
             Chat langsung ke OpenAI/Anthropic pakai API key kamu sendiri
             (disimpan di localStorage browser).

backend/    → FastAPI + SQL (Python)
             Opsional, untuk yang mau API key disimpan aman di server,
             plus Web Search, RAG/Knowledge Base, Agent Mode, Rate Limit,
             Admin Dashboard. WAJIB dijalankan dengan Python (lihat
             backend/README.md untuk langkah instalasinya).
```

## Mana yang harus dipakai?

- **Coba cepat / personal saja** → cukup pakai folder `frontend/`. Buka
  `frontend/index.html` di browser, isi API key di Settings, langsung jalan.
- **Mau lebih aman / fitur lengkap (Web Search, RAG, Agent Mode, Admin Dashboard)**
  → jalankan `backend/` mengikuti `backend/README.md`.

## Status penyambungan frontend ↔ backend

Saat ini `frontend/` dan `backend/` berjalan **terpisah** — frontend memanggil
OpenAI/Anthropic langsung dari browser, backend bisa dites penuh lewat
`http://127.0.0.1:8000/docs` setelah dijalankan. Menyambungkan keduanya
(supaya frontend memakai backend untuk chat, login, dan API key) adalah
langkah lanjutan — beri tahu saya kalau mau saya kerjakan.
