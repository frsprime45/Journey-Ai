/* =========================================================
   JOURNEY AI — frontend app logic (vanilla JS)
   Semua data disimpan di localStorage (tidak ada backend).
   ========================================================= */

/* ---------- Konstanta ---------- */
const MODELS = [
  { id: "openai:gpt-4o", label: "OpenAI · GPT-4o", provider: "openai", vision: true },
  { id: "openai:gpt-4o-mini", label: "OpenAI · GPT-4o mini", provider: "openai", vision: true },
  { id: "openai:gpt-4.1", label: "OpenAI · GPT-4.1", provider: "openai", vision: true },
  { id: "anthropic:claude-sonnet-4-5", label: "Anthropic · Claude Sonnet", provider: "anthropic", vision: true },
  { id: "anthropic:claude-opus-4-5", label: "Anthropic · Claude Opus", provider: "anthropic", vision: true },
  { id: "anthropic:claude-haiku-4-5", label: "Anthropic · Claude Haiku", provider: "anthropic", vision: true },
];

const LS_KEYS = {
  session: "ja_session",
  chats: "ja_chats",
  projects: "ja_projects",
  settings: "ja_settings",
  memory: "ja_memory",
};

const defaultSettings = {
  openaiKey: "",
  anthropicKey: "",
  defaultModel: "openai:gpt-4o-mini",
  customInstructionsAbout: "",
  customInstructionsResponse: "",
  memoryEnabled: true,
  ttsEnabled: false,
  largeText: false,
};

/* ---------- State ---------- */
let DB = {
  session: null,
  chats: [],
  projects: [],
  settings: { ...defaultSettings },
  memory: [],
};

let state = {
  currentChatId: null,
  currentView: "chat",
  currentProjectId: null,
  pendingAttachments: [], // {name, type, dataUrl?, text?, isImage}
  isStreaming: false,
  recognizing: false,
};

/* ---------- Persistence helpers ---------- */
function loadDB() {
  try { DB.session = JSON.parse(localStorage.getItem(LS_KEYS.session) || "null"); } catch (e) { DB.session = null; }
  try { DB.chats = JSON.parse(localStorage.getItem(LS_KEYS.chats) || "[]"); } catch (e) { DB.chats = []; }
  try { DB.projects = JSON.parse(localStorage.getItem(LS_KEYS.projects) || "[]"); } catch (e) { DB.projects = []; }
  try { DB.settings = { ...defaultSettings, ...JSON.parse(localStorage.getItem(LS_KEYS.settings) || "{}") }; } catch (e) { DB.settings = { ...defaultSettings }; }
  try { DB.memory = JSON.parse(localStorage.getItem(LS_KEYS.memory) || "[]"); } catch (e) { DB.memory = []; }
}
function persist(key) {
  const map = { session: "session", chats: "chats", projects: "projects", settings: "settings", memory: "memory" };
  localStorage.setItem(LS_KEYS[map[key]], JSON.stringify(DB[key]));
}
function uid() { return Math.random().toString(36).slice(2, 10) + Date.now().toString(36); }

/* ---------- Icons refresh ---------- */
function refreshIcons() { try { feather.replace({ 'stroke-width': 2 }); } catch (e) {} }

/* ---------- Toast ---------- */
function toast(msg, icon = "check-circle") {
  const el = document.createElement("div");
  el.className = "toast";
  el.innerHTML = `<svg data-feather="${icon}"></svg><span>${escapeHtml(msg)}</span>`;
  document.getElementById("toast-container").appendChild(el);
  refreshIcons();
  setTimeout(() => el.remove(), 3200);
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

/* Very small markdown-ish renderer: code fences + inline code + line breaks */
function renderMarkdown(text) {
  let escaped = escapeHtml(text);
  escaped = escaped.replace(/```([a-zA-Z0-9+#.]*)\n([\s\S]*?)```/g, (m, lang, code) => {
    return `<pre><code>${code}</code></pre>`;
  });
  escaped = escaped.replace(/`([^`]+)`/g, "<code>$1</code>");
  escaped = escaped.replace(/\*\*([^*]+)\*\*/g, "<b>$1</b>");
  return escaped;
}

/* =========================================================
   LOGIN / SESSION
   ========================================================= */
function initLogin() {
  const loginScreen = document.getElementById("login-screen");
  const app = document.getElementById("app");
  if (DB.session && DB.session.name) {
    loginScreen.style.display = "none";
    app.style.display = "flex";
    boot();
    return;
  }
  loginScreen.style.display = "flex";
  app.style.display = "none";
  document.getElementById("login-btn").addEventListener("click", doLogin);
  document.getElementById("login-pin").addEventListener("keydown", e => { if (e.key === "Enter") doLogin(); });
}
function doLogin() {
  const name = document.getElementById("login-name").value.trim();
  if (!name) { toast("Masukkan nama dulu ya", "alert-circle"); return; }
  DB.session = { name, createdAt: Date.now() };
  persist("session");
  document.getElementById("login-screen").style.display = "none";
  document.getElementById("app").style.display = "flex";
  boot();
}
function doLogout() {
  DB.session = null;
  localStorage.removeItem(LS_KEYS.session);
  location.reload();
}

/* =========================================================
   BOOT
   ========================================================= */
function boot() {
  populateModelSelects();
  bindNav();
  bindSidebar();
  bindChatComposer();
  bindFilesPage();
  bindImageGen();
  bindCode();
  bindCalculator();
  bindMemoryView();
  bindInstructionsView();
  bindSettingsView();
  bindProjects();
  bindVoice();
  bindTTS();

  document.getElementById("sidebar-username").textContent = DB.session.name;
  document.getElementById("sidebar-avatar").textContent = DB.session.name.charAt(0).toUpperCase();

  renderSidebarChatList();
  if (DB.chats.length) {
    switchToChat(DB.chats[0].id);
  } else {
    newChat();
  }
  switchView("chat");
  refreshIcons();
}

/* =========================================================
   NAVIGATION
   ========================================================= */
const VIEW_TITLES = {
  chat: ["message-circle", "Chat"],
  dashboard: ["grid", "Dashboard"],
  history: ["clock", "Riwayat Chat"],
  search: ["search", "Cari Chat"],
  projects: ["folder", "Projects"],
  "project-detail": ["folder", "Detail Project"],
  files: ["paperclip", "File & Analisis"],
  "image-gen": ["image", "Image Generation"],
  code: ["code", "Code Assistant"],
  calculator: ["hash", "Kalkulator"],
  websearch: ["globe", "Web Search"],
  agents: ["cpu", "Agent Mode"],
  memory: ["database", "AI Memory"],
  instructions: ["sliders", "Custom Instructions"],
  settings: ["settings", "Settings"],
};

function bindNav() {
  document.querySelectorAll("[data-view]").forEach(el => {
    el.addEventListener("click", () => switchView(el.dataset.view));
  });
  document.getElementById("sidebar-toggle").addEventListener("click", () => {
    document.getElementById("sidebar").classList.toggle("collapsed");
  });
  document.getElementById("logout-btn").addEventListener("click", doLogout);
}

function switchView(view) {
  state.currentView = view;
  document.querySelectorAll(".view").forEach(v => v.classList.remove("active"));
  const el = document.getElementById("view-" + view);
  if (el) el.classList.add("active");

  document.querySelectorAll(".nav-item[data-view]").forEach(n => {
    n.classList.toggle("active", n.dataset.view === view);
  });

  const [icon, title] = VIEW_TITLES[view] || ["compass", "Journey AI"];
  document.getElementById("topbar-title").innerHTML = `<svg data-feather="${icon}"></svg><span>${title}</span>`;
  document.getElementById("topbar-right").style.display = (view === "chat") ? "flex" : "none";

  if (view === "dashboard") renderDashboard();
  if (view === "history") renderHistory();
  if (view === "search") renderSearch();
  if (view === "projects") renderProjects();
  if (view === "files") renderFilesList();
  if (view === "memory") renderMemoryList();

  if (window.innerWidth <= 860) document.getElementById("sidebar").classList.add("collapsed");
  refreshIcons();
}

/* =========================================================
   MODEL SELECT
   ========================================================= */
function populateModelSelects() {
  const selectors = [document.getElementById("model-select"), document.getElementById("default-model")];
  selectors.forEach(sel => {
    if (!sel) return;
    sel.innerHTML = MODELS.map(m => `<option value="${m.id}">${m.label}</option>`).join("");
  });
  document.getElementById("model-select").value = DB.settings.defaultModel;
  document.getElementById("default-model").value = DB.settings.defaultModel;
  document.getElementById("model-select").addEventListener("change", e => {
    if (state.currentChatId) {
      const chat = getChat(state.currentChatId);
      chat.model = e.target.value;
      saveChats();
    }
  });
}
function getModel(id) { return MODELS.find(m => m.id === id) || MODELS[0]; }

/* =========================================================
   CHAT DATA HELPERS
   ========================================================= */
function saveChats() { persist("chats"); renderSidebarChatList(); }
function getChat(id) { return DB.chats.find(c => c.id === id); }

function newChat(projectId = null) {
  const chat = {
    id: uid(),
    title: "Percakapan Baru",
    projectId: projectId,
    model: DB.settings.defaultModel,
    messages: [],
    createdAt: Date.now(),
    updatedAt: Date.now(),
  };
  DB.chats.unshift(chat);
  saveChats();
  switchToChat(chat.id);
  switchView("chat");
}

function switchToChat(id) {
  state.currentChatId = id;
  state.pendingAttachments = [];
  renderComposerAttachments();
  const chat = getChat(id);
  if (chat) document.getElementById("model-select").value = chat.model;
  renderChat();
  renderSidebarChatList();
}

function deleteChat(id) {
  DB.chats = DB.chats.filter(c => c.id !== id);
  saveChats();
  if (state.currentChatId === id) {
    if (DB.chats.length) switchToChat(DB.chats[0].id); else newChat();
  }
  renderHistory();
}

/* =========================================================
   SIDEBAR CHAT LIST
   ========================================================= */
function renderSidebarChatList() {
  const wrap = document.getElementById("sidebar-chat-list");
  const recent = DB.chats.slice(0, 8);
  wrap.innerHTML = recent.map(c => `
    <div class="chat-mini-item ${c.id === state.currentChatId ? "active" : ""}" data-chat="${c.id}">
      <svg data-feather="message-square" style="width:13px;height:13px;"></svg>
      <span>${escapeHtml(c.title)}</span>
    </div>`).join("") || `<div style="padding:10px;color:var(--muted);font-size:12px;">Belum ada chat</div>`;
  wrap.querySelectorAll("[data-chat]").forEach(el => {
    el.addEventListener("click", () => { switchToChat(el.dataset.chat); switchView("chat"); });
  });
  refreshIcons();
}

function bindSidebar() {
  document.getElementById("new-chat-btn").addEventListener("click", () => newChat(state.currentProjectId));
}

/* =========================================================
   CHAT RENDERING
   ========================================================= */
const SUGGESTIONS = [
  { title: "Jelaskan sebuah konsep", sub: "Contoh: apa itu machine learning?" },
  { title: "Bantu menulis kode", sub: "Contoh: buatkan fungsi sorting di Python" },
  { title: "Analisis file", sub: "Unggah dokumen di menu File & Analisis" },
  { title: "Brainstorming ide", sub: "Contoh: ide konten untuk media sosial" },
];

function renderChat() {
  const chat = getChat(state.currentChatId);
  const inner = document.getElementById("chat-inner");
  if (!chat || chat.messages.length === 0) {
    inner.innerHTML = `
      <div class="empty-chat" style="height:60vh;">
        <div class="brand-icon"><svg data-feather="compass"></svg></div>
        <h2>Halo, ${escapeHtml(DB.session.name)} 👋</h2>
        <p>Mulai percakapan dengan Journey AI</p>
        <div class="suggest-grid">
          ${SUGGESTIONS.map(s => `<button class="suggest-card" data-suggest="${escapeHtml(s.sub)}"><b>${s.title}</b>${s.sub}</button>`).join("")}
        </div>
      </div>`;
    inner.querySelectorAll("[data-suggest]").forEach(b => {
      b.addEventListener("click", () => {
        document.getElementById("chat-input").value = b.dataset.suggest;
        onComposerInput();
        document.getElementById("chat-input").focus();
      });
    });
    refreshIcons();
    return;
  }
  inner.innerHTML = chat.messages.map((m, idx) => renderMessageRow(m, idx)).join("");
  refreshIcons();
  attachMessageActions();
  const scroll = document.getElementById("chat-scroll");
  scroll.scrollTop = scroll.scrollHeight;
}

function renderMessageRow(m, idx) {
  const isUser = m.role === "user";
  const avatarIcon = isUser ? (DB.session.name.charAt(0).toUpperCase()) : `<svg data-feather="compass" style="width:16px;height:16px;"></svg>`;
  let attHtml = "";
  if (m.attachments && m.attachments.length) {
    attHtml = `<div class="msg-attachments">` + m.attachments.map(a => {
      if (a.isImage) return `<img class="msg-img" src="${a.dataUrl}" />`;
      return `<span class="att-chip"><svg data-feather="file-text"></svg>${escapeHtml(a.name)}</span>`;
    }).join("") + `</div>`;
  }
  const actions = isUser
    ? `<div class="msg-actions"><button data-act="edit" data-idx="${idx}" title="Edit"><svg data-feather="edit-2"></svg></button><button data-act="copy" data-idx="${idx}" title="Salin"><svg data-feather="copy"></svg></button></div>`
    : `<div class="msg-actions">
         <button data-act="copy" data-idx="${idx}" title="Salin"><svg data-feather="copy"></svg></button>
         <button data-act="regenerate" data-idx="${idx}" title="Buat ulang"><svg data-feather="refresh-cw"></svg></button>
         <button data-act="remember" data-idx="${idx}" title="Simpan ke Memory"><svg data-feather="bookmark"></svg></button>
         <button data-act="speak" data-idx="${idx}" title="Bacakan"><svg data-feather="volume-2"></svg></button>
       </div>`;
  return `
    <div class="msg-row ${isUser ? "user" : "assistant"}" data-idx="${idx}">
      <div class="msg-avatar">${avatarIcon}</div>
      <div class="msg-body">
        <div class="msg-meta">${isUser ? escapeHtml(DB.session.name) : "Journey AI"} · ${formatTime(m.ts)}</div>
        ${attHtml}
        <div class="msg-text">${renderMarkdown(m.content || "")}</div>
        ${actions}
      </div>
    </div>`;
}

function formatTime(ts) {
  if (!ts) return "";
  const d = new Date(ts);
  return d.toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" });
}

function attachMessageActions() {
  document.querySelectorAll("[data-act]").forEach(btn => {
    btn.addEventListener("click", () => {
      const idx = parseInt(btn.dataset.idx, 10);
      const chat = getChat(state.currentChatId);
      const msg = chat.messages[idx];
      const act = btn.dataset.act;
      if (act === "copy") {
        navigator.clipboard.writeText(msg.content).then(() => toast("Disalin ke clipboard"));
      } else if (act === "edit") {
        document.getElementById("chat-input").value = msg.content;
        chat.messages = chat.messages.slice(0, idx);
        saveChats(); renderChat();
        onComposerInput();
      } else if (act === "regenerate") {
        chat.messages = chat.messages.slice(0, idx);
        saveChats(); renderChat();
        runAssistantReply(chat);
      } else if (act === "remember") {
        addMemoryFact(msg.content.slice(0, 200));
        toast("Disimpan ke AI Memory", "database");
      } else if (act === "speak") {
        speakText(msg.content);
      }
    });
  });
}

/* =========================================================
   COMPOSER
   ========================================================= */
function bindChatComposer() {
  const input = document.getElementById("chat-input");
  const sendBtn = document.getElementById("send-btn");
  input.addEventListener("input", onComposerInput);
  input.addEventListener("keydown", e => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  });
  sendBtn.addEventListener("click", sendMessage);

  document.getElementById("attach-btn").addEventListener("click", () => document.getElementById("file-input").click());
  document.getElementById("file-input").addEventListener("change", async e => {
    for (const f of e.target.files) await handleAttachFile(f);
    e.target.value = "";
    renderComposerAttachments();
  });
}
function onComposerInput() {
  const input = document.getElementById("chat-input");
  input.style.height = "auto";
  input.style.height = Math.min(input.scrollHeight, 180) + "px";
  document.getElementById("send-btn").disabled = !(input.value.trim().length || state.pendingAttachments.length) || state.isStreaming;
}

async function handleAttachFile(file) {
  const isImage = file.type.startsWith("image/");
  if (isImage) {
    const dataUrl = await fileToDataUrl(file);
    state.pendingAttachments.push({ name: file.name, isImage: true, dataUrl });
  } else {
    const text = await extractTextFromFile(file);
    state.pendingAttachments.push({ name: file.name, isImage: false, text });
  }
  onComposerInput();
}

function renderComposerAttachments() {
  const wrap = document.getElementById("composer-atts");
  wrap.innerHTML = state.pendingAttachments.map((a, i) => `
    <span class="att-chip">
      <svg data-feather="${a.isImage ? "image" : "file-text"}"></svg>${escapeHtml(a.name)}
      <button data-remove-att="${i}" style="background:none;border:none;color:var(--muted);cursor:pointer;">✕</button>
    </span>`).join("");
  wrap.querySelectorAll("[data-remove-att]").forEach(b => {
    b.addEventListener("click", () => {
      state.pendingAttachments.splice(parseInt(b.dataset.removeAtt, 10), 1);
      renderComposerAttachments();
      onComposerInput();
    });
  });
  refreshIcons();
}

async function sendMessage() {
  const input = document.getElementById("chat-input");
  const text = input.value.trim();
  if (!text && state.pendingAttachments.length === 0) return;
  if (state.isStreaming) return;

  const chat = getChat(state.currentChatId);
  const model = getModel(chat.model);

  if (!hasKeyFor(model.provider)) {
    toast(`API key ${model.provider === "openai" ? "OpenAI" : "Anthropic"} belum diisi di Settings`, "alert-triangle");
    switchView("settings");
    document.querySelector('[data-tab="tab-models"]').click();
    return;
  }

  const userMsg = { role: "user", content: text, attachments: state.pendingAttachments, ts: Date.now() };
  chat.messages.push(userMsg);
  if (chat.title === "Percakapan Baru" && text) chat.title = text.slice(0, 42);
  chat.updatedAt = Date.now();
  state.pendingAttachments = [];
  input.value = ""; input.style.height = "auto";
  renderComposerAttachments();
  saveChats();
  renderChat();

  await runAssistantReply(chat);
}

function hasKeyFor(provider) {
  return provider === "openai" ? !!DB.settings.openaiKey : !!DB.settings.anthropicKey;
}

/* =========================================================
   SYSTEM PROMPT BUILDER
   ========================================================= */
function buildSystemPrompt(chat) {
  let parts = ["Kamu adalah Journey AI, asisten AI yang membantu, jujur, dan ringkas. Jawab dalam bahasa yang dipakai pengguna."];
  if (DB.settings.customInstructionsAbout) parts.push(`Tentang pengguna: ${DB.settings.customInstructionsAbout}`);
  if (DB.settings.customInstructionsResponse) parts.push(`Gaya respons yang diinginkan: ${DB.settings.customInstructionsResponse}`);
  if (DB.settings.memoryEnabled && DB.memory.length) {
    parts.push("Informasi yang diizinkan untuk diingat tentang pengguna:\n" + DB.memory.map(f => "- " + f.text).join("\n"));
  }
  if (chat.projectId) {
    const proj = DB.projects.find(p => p.id === chat.projectId);
    if (proj) {
      if (proj.instructions) parts.push(`Instruksi khusus project "${proj.name}": ${proj.instructions}`);
      if (proj.files && proj.files.length) {
        parts.push("Konteks file project:\n" + proj.files.map(f => `[${f.name}]\n${(f.text || "").slice(0, 3000)}`).join("\n\n"));
      }
    }
  }
  return parts.join("\n\n");
}

/* =========================================================
   ASSISTANT REPLY (streaming, multi-provider)
   ========================================================= */
async function runAssistantReply(chat) {
  state.isStreaming = true;
  onComposerInput();
  const model = getModel(chat.model);
  const system = buildSystemPrompt(chat);

  const assistantMsg = { role: "assistant", content: "", ts: Date.now() };
  chat.messages.push(assistantMsg);
  renderChat();
  const rowIdx = chat.messages.length - 1;

  const onDelta = (delta) => {
    assistantMsg.content += delta;
    updateStreamingBubble(rowIdx, assistantMsg.content);
  };

  try {
    if (model.provider === "openai") {
      await streamOpenAI(chat, model, system, onDelta);
    } else {
      await streamAnthropic(chat, model, system, onDelta);
    }
  } catch (err) {
    assistantMsg.content += `\n\n⚠ Terjadi kesalahan: ${err.message}`;
    updateStreamingBubble(rowIdx, assistantMsg.content);
  }

  state.isStreaming = false;
  onComposerInput();
  saveChats();
  renderChat();
  if (DB.settings.ttsEnabled) speakText(assistantMsg.content);
}

function updateStreamingBubble(rowIdx, content) {
  const row = document.querySelector(`.msg-row[data-idx="${rowIdx}"] .msg-text`);
  if (row) {
    row.innerHTML = renderMarkdown(content || "") + `<span class="typing-dots"><span></span><span></span><span></span></span>`;
    const scroll = document.getElementById("chat-scroll");
    scroll.scrollTop = scroll.scrollHeight;
  } else {
    renderChat();
  }
}

function toOpenAIMessages(chat, system) {
  const msgs = [{ role: "system", content: system }];
  chat.messages.slice(0, -1).forEach(m => {
    if (m.attachments && m.attachments.some(a => a.isImage)) {
      const content = [];
      if (m.content) content.push({ type: "text", text: m.content });
      m.attachments.forEach(a => {
        if (a.isImage) content.push({ type: "image_url", image_url: { url: a.dataUrl } });
        else content.push({ type: "text", text: `[File: ${a.name}]\n${(a.text || "").slice(0, 4000)}` });
      });
      msgs.push({ role: m.role, content });
    } else {
      let text = m.content || "";
      if (m.attachments && m.attachments.length) {
        text += "\n\n" + m.attachments.map(a => `[File: ${a.name}]\n${(a.text || "").slice(0, 4000)}`).join("\n\n");
      }
      msgs.push({ role: m.role, content: text });
    }
  });
  return msgs;
}

async function streamOpenAI(chat, model, system, onDelta) {
  const modelName = model.id.split(":")[1];
  const messages = toOpenAIMessages(chat, system);
  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", "Authorization": `Bearer ${DB.settings.openaiKey}` },
    body: JSON.stringify({ model: modelName, messages, stream: true, temperature: 0.7 }),
  });
  if (!res.ok) {
    const errBody = await safeJson(res);
    throw new Error(errBody?.error?.message || `HTTP ${res.status}`);
  }
  await readSSE(res, (jsonStr) => {
    if (jsonStr === "[DONE]") return;
    try {
      const obj = JSON.parse(jsonStr);
      const delta = obj.choices?.[0]?.delta?.content;
      if (delta) onDelta(delta);
    } catch (e) {}
  });
}

function toAnthropicMessages(chat) {
  const msgs = [];
  chat.messages.slice(0, -1).forEach(m => {
    const content = [];
    if (m.content) content.push({ type: "text", text: m.content });
    (m.attachments || []).forEach(a => {
      if (a.isImage) {
        const [, meta, b64] = a.dataUrl.match(/^data:(.+);base64,(.*)$/) || [];
        if (b64) content.push({ type: "image", source: { type: "base64", media_type: meta, data: b64 } });
      } else {
        content.push({ type: "text", text: `[File: ${a.name}]\n${(a.text || "").slice(0, 4000)}` });
      }
    });
    msgs.push({ role: m.role === "assistant" ? "assistant" : "user", content });
  });
  return msgs;
}

async function streamAnthropic(chat, model, system, onDelta) {
  const modelName = model.id.split(":")[1];
  const messages = toAnthropicMessages(chat);
  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": DB.settings.anthropicKey,
      "anthropic-version": "2023-06-01",
      "anthropic-dangerous-direct-browser-access": "true",
    },
    body: JSON.stringify({ model: modelName, system, messages, max_tokens: 2048, stream: true }),
  });
  if (!res.ok) {
    const errBody = await safeJson(res);
    throw new Error(errBody?.error?.message || `HTTP ${res.status}`);
  }
  await readSSE(res, (jsonStr) => {
    try {
      const obj = JSON.parse(jsonStr);
      if (obj.type === "content_block_delta" && obj.delta?.text) onDelta(obj.delta.text);
    } catch (e) {}
  });
}

async function safeJson(res) { try { return await res.json(); } catch (e) { return null; } }

async function readSSE(res, onEvent) {
  const reader = res.body.getReader();
  const decoder = new TextDecoder("utf-8");
  let buffer = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split("\n");
    buffer = lines.pop();
    for (const line of lines) {
      const trimmed = line.trim();
      if (trimmed.startsWith("data:")) {
        onEvent(trimmed.slice(5).trim());
      }
    }
  }
}

/* Non-streaming helper for Code Assistant / Image Gen prompts */
async function askAIOnce(promptText, { system = "Kamu adalah asisten AI yang ahli membantu programmer.", modelId = null } = {}) {
  const model = getModel(modelId || DB.settings.defaultModel);
  if (!hasKeyFor(model.provider)) throw new Error(`API key ${model.provider} belum diisi di Settings`);
  let full = "";
  const fakeChat = { messages: [{ role: "user", content: promptText, ts: Date.now() }] };
  if (model.provider === "openai") {
    await streamOpenAI(fakeChat, model, system, d => full += d);
  } else {
    await streamAnthropic(fakeChat, model, system, d => full += d);
  }
  return full;
}

/* =========================================================
   FILE HANDLING (extraction)
   ========================================================= */
function fileToDataUrl(file) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = rej;
    r.readAsDataURL(file);
  });
}
function fileToText(file) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = rej;
    r.readAsText(file);
  });
}
function fileToArrayBuffer(file) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = rej;
    r.readAsArrayBuffer(file);
  });
}

async function extractTextFromFile(file) {
  const ext = file.name.split(".").pop().toLowerCase();
  try {
    if (ext === "txt" || ext === "md" || ext === "csv" || ext === "json") {
      return await fileToText(file);
    }
    if (ext === "pdf" && window.pdfjsLib) {
      pdfjsLib.GlobalWorkerOptions.workerSrc = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";
      const buf = await fileToArrayBuffer(file);
      const pdf = await pdfjsLib.getDocument({ data: buf }).promise;
      let text = "";
      for (let i = 1; i <= Math.min(pdf.numPages, 30); i++) {
        const page = await pdf.getPage(i);
        const content = await page.getTextContent();
        text += content.items.map(it => it.str).join(" ") + "\n";
      }
      return text;
    }
    if (ext === "docx" && window.mammoth) {
      const buf = await fileToArrayBuffer(file);
      const result = await mammoth.extractRawText({ arrayBuffer: buf });
      return result.value;
    }
  } catch (e) {
    return `[Gagal membaca isi file: ${e.message}]`;
  }
  return "[Format file ini belum didukung untuk ekstraksi teks otomatis]";
}

/* =========================================================
   FILES PAGE
   ========================================================= */
let uploadedFiles = JSON.parse(localStorage.getItem("ja_uploaded_files") || "[]");
function saveUploadedFiles() { localStorage.setItem("ja_uploaded_files", JSON.stringify(uploadedFiles)); }

function bindFilesPage() {
  const drop = document.getElementById("files-drop");
  const input = document.getElementById("files-page-input");
  drop.addEventListener("click", () => input.click());
  drop.addEventListener("dragover", e => { e.preventDefault(); drop.style.borderColor = "var(--accent)"; });
  drop.addEventListener("dragleave", () => drop.style.borderColor = "");
  drop.addEventListener("drop", async e => {
    e.preventDefault(); drop.style.borderColor = "";
    for (const f of e.dataTransfer.files) await addUploadedFile(f);
    renderFilesList();
  });
  input.addEventListener("change", async e => {
    for (const f of e.target.files) await addUploadedFile(f);
    e.target.value = "";
    renderFilesList();
  });
}
async function addUploadedFile(file) {
  const isImage = file.type.startsWith("image/");
  const entry = { id: uid(), name: file.name, isImage, addedAt: Date.now() };
  if (isImage) entry.dataUrl = await fileToDataUrl(file);
  else entry.text = await extractTextFromFile(file);
  uploadedFiles.unshift(entry);
  saveUploadedFiles();
  toast(`${file.name} berhasil diunggah`);
}
function renderFilesList() {
  const wrap = document.getElementById("files-list");
  if (!wrap) return;
  if (!uploadedFiles.length) {
    wrap.innerHTML = `<div class="empty-state"><svg data-feather="inbox"></svg><h3>Belum ada file</h3><p>Unggah file untuk mulai dianalisis AI</p></div>`;
    refreshIcons();
    return;
  }
  wrap.innerHTML = uploadedFiles.map(f => `
    <div class="list-row">
      <div class="list-icon"><svg data-feather="${f.isImage ? "image" : "file-text"}"></svg></div>
      <div>
        <div class="list-title">${escapeHtml(f.name)}</div>
        <div class="list-sub">${new Date(f.addedAt).toLocaleString("id-ID")}</div>
      </div>
      <div class="list-actions">
        <button class="btn" data-analyze="${f.id}"><svg data-feather="zap"></svg> Analisis di Chat</button>
        <button class="icon-btn" data-del-file="${f.id}"><svg data-feather="trash-2"></svg></button>
      </div>
    </div>`).join("");
  wrap.querySelectorAll("[data-analyze]").forEach(b => {
    b.addEventListener("click", () => {
      const f = uploadedFiles.find(x => x.id === b.dataset.analyze);
      state.pendingAttachments.push(f.isImage ? { name: f.name, isImage: true, dataUrl: f.dataUrl } : { name: f.name, isImage: false, text: f.text });
      switchView("chat");
      renderComposerAttachments();
      onComposerInput();
      document.getElementById("chat-input").focus();
    });
  });
  wrap.querySelectorAll("[data-del-file]").forEach(b => {
    b.addEventListener("click", () => {
      uploadedFiles = uploadedFiles.filter(x => x.id !== b.dataset.delFile);
      saveUploadedFiles(); renderFilesList();
    });
  });
  refreshIcons();
}

/* =========================================================
   IMAGE GENERATION (DALL·E via OpenAI)
   ========================================================= */
function bindImageGen() {
  document.getElementById("imggen-btn").addEventListener("click", async () => {
    const prompt = document.getElementById("imggen-prompt").value.trim();
    if (!prompt) { toast("Tulis prompt gambar dulu", "alert-circle"); return; }
    if (!DB.settings.openaiKey) { toast("API key OpenAI belum diisi", "alert-triangle"); switchView("settings"); return; }
    const size = document.getElementById("imggen-size").value;
    const btn = document.getElementById("imggen-btn");
    btn.disabled = true; btn.innerHTML = `<svg data-feather="loader"></svg> Membuat...`; refreshIcons();
    try {
      const res = await fetch("https://api.openai.com/v1/images/generations", {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${DB.settings.openaiKey}` },
        body: JSON.stringify({ model: "dall-e-3", prompt, size, n: 1 }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error?.message || "Gagal membuat gambar");
      const url = data.data[0].url;
      const wrap = document.getElementById("imggen-results");
      const card = document.createElement("div");
      card.className = "card";
      card.innerHTML = `<img src="${url}" style="width:100%;border-radius:8px;margin-bottom:8px;" /><div style="font-size:11.5px;color:var(--muted);">${escapeHtml(prompt.slice(0, 60))}</div>`;
      wrap.prepend(card);
    } catch (e) {
      toast(e.message, "alert-triangle");
    }
    btn.disabled = false; btn.innerHTML = `<svg data-feather="image"></svg> Buat Gambar`; refreshIcons();
  });
}

/* =========================================================
   CODE ASSISTANT
   ========================================================= */
function bindCode() {
  const out = document.getElementById("code-output");
  async function run(kind) {
    const lang = document.getElementById("code-lang").value;
    const code = document.getElementById("code-input").value.trim();
    if (!code) { toast("Isi kode / permintaan dulu", "alert-circle"); return; }
    out.textContent = "Memproses...";
    let sys = "Kamu adalah asisten pemrograman ahli. Jawab dengan kode yang rapi dan penjelasan singkat dalam Bahasa Indonesia.";
    let prompt = "";
    if (kind === "explain") prompt = `Jelaskan kode ${lang} berikut secara ringkas per bagian:\n\n${code}`;
    if (kind === "fix") prompt = `Perbaiki bug/kesalahan pada kode ${lang} berikut, tampilkan kode hasil perbaikan dan jelaskan apa yang diperbaiki:\n\n${code}`;
    if (kind === "write") prompt = `Buatkan kode ${lang} untuk permintaan berikut:\n\n${code}`;
    try {
      const result = await askAIOnce(prompt, { system: sys });
      out.innerHTML = renderMarkdown(result);
    } catch (e) {
      out.textContent = "⚠ " + e.message;
    }
  }
  document.getElementById("code-explain-btn").addEventListener("click", () => run("explain"));
  document.getElementById("code-fix-btn").addEventListener("click", () => run("fix"));
  document.getElementById("code-write-btn").addEventListener("click", () => run("write"));
}

/* =========================================================
   CALCULATOR
   ========================================================= */
function bindCalculator() {
  const keys = ["7","8","9","/","4","5","6","*","1","2","3","-","0",".","C","+","(",")","%","="];
  const grid = document.getElementById("calc-grid");
  const display = document.getElementById("calc-input");
  grid.innerHTML = keys.map(k => `<button class="calc-btn ${["/","*","-","+","%","(",")"].includes(k) ? "op" : ""} ${k === "=" ? "eq" : ""}" data-key="${k}">${k}</button>`).join("");
  grid.querySelectorAll("[data-key]").forEach(btn => {
    btn.addEventListener("click", () => {
      const k = btn.dataset.key;
      if (k === "C") { display.value = "0"; return; }
      if (k === "=") {
        try {
          const expr = display.value.replace(/%/g, "/100");
          const result = math.evaluate(expr);
          display.value = String(result);
        } catch (e) { display.value = "Error"; }
        return;
      }
      if (display.value === "0" || display.value === "Error") display.value = "";
      display.value += k;
    });
  });
  display.addEventListener("keydown", e => {
    if (e.key === "Enter") {
      try { display.value = String(math.evaluate(display.value.replace(/%/g, "/100"))); }
      catch (er) { display.value = "Error"; }
    }
  });
}

/* =========================================================
   MEMORY
   ========================================================= */
function bindMemoryView() {
  document.getElementById("memory-add-btn").addEventListener("click", () => {
    const input = document.getElementById("memory-input");
    if (input.value.trim()) { addMemoryFact(input.value.trim()); input.value = ""; }
  });
  document.getElementById("memory-enabled-toggle").addEventListener("change", e => {
    DB.settings.memoryEnabled = e.target.checked;
    persist("settings");
    document.getElementById("settings-memory-toggle").checked = e.target.checked;
  });
}
function addMemoryFact(text) {
  DB.memory.unshift({ id: uid(), text, addedAt: Date.now() });
  persist("memory");
  renderMemoryList();
}
function renderMemoryList() {
  const wrap = document.getElementById("memory-list");
  if (!wrap) return;
  document.getElementById("memory-enabled-toggle").checked = DB.settings.memoryEnabled;
  if (!DB.memory.length) {
    wrap.innerHTML = `<div class="empty-state"><svg data-feather="database"></svg><h3>Belum ada memory</h3><p>Tambahkan informasi yang boleh diingat AI</p></div>`;
    refreshIcons();
    return;
  }
  wrap.innerHTML = DB.memory.map(f => `
    <div class="memory-fact">
      <svg data-feather="bookmark"></svg>
      <p>${escapeHtml(f.text)}</p>
      <button data-del-mem="${f.id}"><svg data-feather="x"></svg></button>
    </div>`).join("");
  wrap.querySelectorAll("[data-del-mem]").forEach(b => {
    b.addEventListener("click", () => {
      DB.memory = DB.memory.filter(f => f.id !== b.dataset.delMem);
      persist("memory"); renderMemoryList();
    });
  });
  refreshIcons();
}

/* =========================================================
   CUSTOM INSTRUCTIONS
   ========================================================= */
function bindInstructionsView() {
  document.getElementById("instr-about").value = DB.settings.customInstructionsAbout;
  document.getElementById("instr-response").value = DB.settings.customInstructionsResponse;
  document.getElementById("instr-save-btn").addEventListener("click", () => {
    DB.settings.customInstructionsAbout = document.getElementById("instr-about").value;
    DB.settings.customInstructionsResponse = document.getElementById("instr-response").value;
    persist("settings");
    toast("Custom instructions disimpan");
  });
}

/* =========================================================
   SETTINGS
   ========================================================= */
function bindSettingsView() {
  document.querySelectorAll(".tab-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
      document.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById(btn.dataset.tab).classList.add("active");
    });
  });

  document.getElementById("acc-name").value = DB.session ? DB.session.name : "";
  document.getElementById("acc-save-btn").addEventListener("click", () => {
    const name = document.getElementById("acc-name").value.trim();
    if (!name) return;
    DB.session.name = name;
    persist("session");
    document.getElementById("sidebar-username").textContent = name;
    document.getElementById("sidebar-avatar").textContent = name.charAt(0).toUpperCase();
    toast("Profil diperbarui");
  });

  document.getElementById("key-openai").value = DB.settings.openaiKey;
  document.getElementById("key-anthropic").value = DB.settings.anthropicKey;
  document.querySelectorAll(".toggle-visibility").forEach(btn => {
    btn.addEventListener("click", () => {
      const target = document.getElementById(btn.dataset.target);
      target.type = target.type === "password" ? "text" : "password";
    });
  });
  document.getElementById("keys-save-btn").addEventListener("click", () => {
    DB.settings.openaiKey = document.getElementById("key-openai").value.trim();
    DB.settings.anthropicKey = document.getElementById("key-anthropic").value.trim();
    DB.settings.defaultModel = document.getElementById("default-model").value;
    persist("settings");
    document.getElementById("model-select").value = DB.settings.defaultModel;
    toast("Pengaturan model & API key disimpan");
  });

  document.getElementById("settings-memory-toggle").checked = DB.settings.memoryEnabled;
  document.getElementById("settings-memory-toggle").addEventListener("change", e => {
    DB.settings.memoryEnabled = e.target.checked;
    persist("settings");
    document.getElementById("memory-enabled-toggle").checked = e.target.checked;
  });

  document.getElementById("app-large-text").checked = DB.settings.largeText;
  document.getElementById("app-large-text").addEventListener("change", e => {
    DB.settings.largeText = e.target.checked;
    document.body.style.fontSize = e.target.checked ? "15.5px" : "14px";
    persist("settings");
  });

  document.getElementById("clear-data-btn").addEventListener("click", () => {
    if (confirm("Yakin ingin menghapus semua data lokal (chat, project, memory, API key)? Tindakan ini tidak bisa dibatalkan.")) {
      localStorage.clear();
      location.reload();
    }
  });
}

/* =========================================================
   PROJECTS
   ========================================================= */
function bindProjects() {
  document.getElementById("new-project-btn").addEventListener("click", () => {
    const name = prompt("Nama project:");
    if (!name) return;
    const proj = { id: uid(), name, description: "", instructions: "", files: [], createdAt: Date.now() };
    DB.projects.unshift(proj);
    persist("projects");
    renderProjects();
  });
}
function renderProjects() {
  const wrap = document.getElementById("projects-list");
  if (!DB.projects.length) {
    wrap.innerHTML = `<div class="empty-state"><svg data-feather="folder"></svg><h3>Belum ada project</h3><p>Buat project untuk mengelompokkan chat dan file</p></div>`;
    refreshIcons();
    return;
  }
  wrap.innerHTML = DB.projects.map(p => {
    const chatCount = DB.chats.filter(c => c.projectId === p.id).length;
    return `
    <div class="list-row">
      <div class="list-icon"><svg data-feather="folder"></svg></div>
      <div>
        <div class="list-title">${escapeHtml(p.name)}</div>
        <div class="list-sub">${chatCount} chat · ${p.files.length} file</div>
      </div>
      <div class="list-actions">
        <button class="btn" data-open-proj="${p.id}"><svg data-feather="arrow-right"></svg> Buka</button>
        <button class="icon-btn" data-del-proj="${p.id}"><svg data-feather="trash-2"></svg></button>
      </div>
    </div>`;
  }).join("");
  wrap.querySelectorAll("[data-open-proj]").forEach(b => b.addEventListener("click", () => openProjectDetail(b.dataset.openProj)));
  wrap.querySelectorAll("[data-del-proj]").forEach(b => b.addEventListener("click", () => {
    if (!confirm("Hapus project ini? Chat di dalamnya tidak akan terhapus.")) return;
    DB.projects = DB.projects.filter(p => p.id !== b.dataset.delProj);
    persist("projects"); renderProjects();
  }));
  refreshIcons();
}

function openProjectDetail(id) {
  state.currentProjectId = id;
  const proj = DB.projects.find(p => p.id === id);
  const page = document.getElementById("project-detail-page");
  const chats = DB.chats.filter(c => c.projectId === id);
  page.innerHTML = `
    <div class="page-head">
      <div><h1>${escapeHtml(proj.name)}</h1><p>Chat, file, dan instruksi khusus project ini</p></div>
      <button class="btn accent" id="proj-new-chat"><svg data-feather="plus"></svg> Chat Baru di Project</button>
    </div>
    <div class="grid-2">
      <div class="card">
        <div class="field"><label>Instruksi khusus project</label><textarea id="proj-instructions" rows="4">${escapeHtml(proj.instructions || "")}</textarea></div>
        <button class="btn accent" id="proj-save-instr"><svg data-feather="check"></svg> Simpan</button>
      </div>
      <div class="card">
        <div class="field"><label>Knowledge / File project</label></div>
        <input type="file" id="proj-file-input" multiple style="margin-bottom:10px;" accept=".txt,.md,.csv,.json,.pdf,.docx" />
        <div id="proj-files-list"></div>
      </div>
    </div>
    <h3 style="margin:24px 0 10px;font-size:15px;">Chat di project ini</h3>
    <div id="proj-chats-list"></div>
  `;
  document.getElementById("proj-new-chat").addEventListener("click", () => newChat(id));
  document.getElementById("proj-save-instr").addEventListener("click", () => {
    proj.instructions = document.getElementById("proj-instructions").value;
    persist("projects");
    toast("Instruksi project disimpan");
  });
  document.getElementById("proj-file-input").addEventListener("change", async e => {
    for (const f of e.target.files) {
      const text = await extractTextFromFile(f);
      proj.files.push({ name: f.name, text });
    }
    persist("projects");
    renderProjectFiles(proj);
    e.target.value = "";
  });
  renderProjectFiles(proj);

  const chatsWrap = document.getElementById("proj-chats-list");
  chatsWrap.innerHTML = chats.length ? chats.map(c => `
    <div class="list-row" data-open-chat="${c.id}" style="cursor:pointer;">
      <div class="list-icon"><svg data-feather="message-square"></svg></div>
      <div><div class="list-title">${escapeHtml(c.title)}</div><div class="list-sub">${new Date(c.updatedAt).toLocaleString("id-ID")}</div></div>
    </div>`).join("") : `<div class="empty-state"><svg data-feather="message-circle"></svg><h3>Belum ada chat</h3></div>`;
  chatsWrap.querySelectorAll("[data-open-chat]").forEach(el => el.addEventListener("click", () => { switchToChat(el.dataset.openChat); switchView("chat"); }));

  switchView("project-detail");
}
function renderProjectFiles(proj) {
  const wrap = document.getElementById("proj-files-list");
  wrap.innerHTML = proj.files.length ? proj.files.map((f, i) => `
    <div class="att-chip" style="margin-bottom:6px;"><svg data-feather="file-text"></svg>${escapeHtml(f.name)}
      <button data-rm-pf="${i}" style="background:none;border:none;color:var(--muted);cursor:pointer;">✕</button></div>`).join("")
    : `<div class="field-hint">Belum ada file</div>`;
  wrap.querySelectorAll("[data-rm-pf]").forEach(b => b.addEventListener("click", () => {
    proj.files.splice(parseInt(b.dataset.rmPf, 10), 1);
    persist("projects"); renderProjectFiles(proj);
  }));
  refreshIcons();
}

/* =========================================================
   HISTORY & SEARCH
   ========================================================= */
function renderHistory() {
  const wrap = document.getElementById("history-list");
  if (!DB.chats.length) {
    wrap.innerHTML = `<div class="empty-state"><svg data-feather="clock"></svg><h3>Belum ada riwayat</h3></div>`;
    refreshIcons();
    return;
  }
  wrap.innerHTML = DB.chats.map(c => `
    <div class="list-row">
      <div class="list-icon"><svg data-feather="message-square"></svg></div>
      <div style="cursor:pointer;flex:1;" data-open-chat="${c.id}">
        <div class="list-title">${escapeHtml(c.title)}</div>
        <div class="list-sub">${c.messages.length} pesan · ${new Date(c.updatedAt).toLocaleString("id-ID")}</div>
      </div>
      <div class="list-actions">
        <button class="icon-btn" data-del-chat="${c.id}" title="Hapus"><svg data-feather="trash-2"></svg></button>
      </div>
    </div>`).join("");
  wrap.querySelectorAll("[data-open-chat]").forEach(el => el.addEventListener("click", () => { switchToChat(el.dataset.openChat); switchView("chat"); }));
  wrap.querySelectorAll("[data-del-chat]").forEach(el => el.addEventListener("click", (e) => { e.stopPropagation(); if (confirm("Hapus chat ini?")) deleteChat(el.dataset.delChat); }));
  refreshIcons();
}

function renderSearch() {
  document.getElementById("search-input").oninput = (e) => {
    const q = e.target.value.trim().toLowerCase();
    const wrap = document.getElementById("search-results");
    if (!q) { wrap.innerHTML = ""; return; }
    const results = DB.chats.filter(c =>
      c.title.toLowerCase().includes(q) || c.messages.some(m => (m.content || "").toLowerCase().includes(q))
    );
    wrap.innerHTML = results.length ? results.map(c => `
      <div class="list-row" data-open-chat="${c.id}" style="cursor:pointer;">
        <div class="list-icon"><svg data-feather="message-square"></svg></div>
        <div><div class="list-title">${escapeHtml(c.title)}</div><div class="list-sub">${c.messages.length} pesan</div></div>
      </div>`).join("") : `<div class="empty-state"><svg data-feather="search"></svg><h3>Tidak ditemukan</h3></div>`;
    wrap.querySelectorAll("[data-open-chat]").forEach(el => el.addEventListener("click", () => { switchToChat(el.dataset.openChat); switchView("chat"); }));
    refreshIcons();
  };
}

/* =========================================================
   DASHBOARD
   ========================================================= */
function renderDashboard() {
  const totalMsgs = DB.chats.reduce((s, c) => s + c.messages.length, 0);
  const page = document.getElementById("dashboard-page");
  const recent = DB.chats.slice(0, 5);
  page.innerHTML = `
    <div class="page-head"><div><h1>Dashboard</h1><p>Halo, ${escapeHtml(DB.session.name)}. Ini ringkasan aktivitasmu.</p></div></div>
    <div class="grid-3" style="margin-bottom:26px;">
      <div class="stat-card"><div class="stat-num">${DB.chats.length}</div><div class="stat-label">Total Percakapan</div></div>
      <div class="stat-card"><div class="stat-num">${totalMsgs}</div><div class="stat-label">Total Pesan</div></div>
      <div class="stat-card"><div class="stat-num">${DB.projects.length}</div><div class="stat-label">Projects</div></div>
    </div>
    <h3 style="font-size:15px;margin-bottom:10px;">Quick Actions</h3>
    <div class="grid-3" style="margin-bottom:26px;">
      <button class="suggest-card" id="qa-newchat"><b>Percakapan Baru</b>Mulai chat dengan AI</button>
      <button class="suggest-card" id="qa-upload"><b>Unggah File</b>Analisis dokumen/gambar</button>
      <button class="suggest-card" id="qa-project"><b>Project Baru</b>Kelompokkan pekerjaanmu</button>
    </div>
    <h3 style="font-size:15px;margin-bottom:10px;">Chat Terbaru</h3>
    <div id="dash-recent"></div>
  `;
  const rec = document.getElementById("dash-recent");
  rec.innerHTML = recent.length ? recent.map(c => `
    <div class="list-row" data-open-chat="${c.id}" style="cursor:pointer;">
      <div class="list-icon"><svg data-feather="message-square"></svg></div>
      <div><div class="list-title">${escapeHtml(c.title)}</div><div class="list-sub">${new Date(c.updatedAt).toLocaleString("id-ID")}</div></div>
    </div>`).join("") : `<div class="empty-state"><svg data-feather="message-circle"></svg><h3>Belum ada chat</h3></div>`;
  rec.querySelectorAll("[data-open-chat]").forEach(el => el.addEventListener("click", () => { switchToChat(el.dataset.openChat); switchView("chat"); }));
  document.getElementById("qa-newchat").addEventListener("click", () => newChat());
  document.getElementById("qa-upload").addEventListener("click", () => switchView("files"));
  document.getElementById("qa-project").addEventListener("click", () => switchView("projects"));
  refreshIcons();
}

/* =========================================================
   VOICE INPUT
   ========================================================= */
function bindVoice() {
  const micBtn = document.getElementById("mic-btn");
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (!SR) {
    micBtn.addEventListener("click", () => toast("Voice input tidak didukung di browser ini", "mic-off"));
    return;
  }
  const recognition = new SR();
  recognition.lang = "id-ID";
  recognition.interimResults = false;
  recognition.continuous = false;

  micBtn.addEventListener("click", () => {
    if (state.recognizing) { recognition.stop(); return; }
    try { recognition.start(); state.recognizing = true; micBtn.classList.add("recording"); }
    catch (e) {}
  });
  recognition.onresult = (e) => {
    const text = Array.from(e.results).map(r => r[0].transcript).join(" ");
    const input = document.getElementById("chat-input");
    input.value = (input.value ? input.value + " " : "") + text;
    onComposerInput();
  };
  recognition.onend = () => { state.recognizing = false; micBtn.classList.remove("recording"); };
  recognition.onerror = () => { state.recognizing = false; micBtn.classList.remove("recording"); };
}

/* =========================================================
   TEXT TO SPEECH
   ========================================================= */
function bindTTS() {
  const btn = document.getElementById("tts-toggle");
  btn.classList.toggle("on", DB.settings.ttsEnabled);
  btn.addEventListener("click", () => {
    DB.settings.ttsEnabled = !DB.settings.ttsEnabled;
    persist("settings");
    btn.classList.toggle("on", DB.settings.ttsEnabled);
    toast(DB.settings.ttsEnabled ? "AI akan membacakan jawaban" : "Text-to-Speech dimatikan");
  });
}
function speakText(text) {
  if (!("speechSynthesis" in window)) { toast("Text-to-Speech tidak didukung di browser ini"); return; }
  window.speechSynthesis.cancel();
  const utter = new SpeechSynthesisUtterance(text.replace(/```[\s\S]*?```/g, " kode. "));
  utter.lang = "id-ID";
  window.speechSynthesis.speak(utter);
}

/* =========================================================
   INIT
   ========================================================= */
document.addEventListener("DOMContentLoaded", () => {
  loadDB();
  if (DB.settings.largeText) document.body.style.fontSize = "15.5px";
  initLogin();
});
